import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const years = pgTable("years", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const semesters = pgTable("semesters", {
  id: serial("id").primaryKey(),
  yearId: integer("year_id").notNull(),
  name: text("name").notNull(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  semesterId: integer("semester_id").notNull(),
  name: text("name").notNull(),
});

export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").notNull(),
  title: text("title").notNull(),
  number: text("number").notNull(),
  givenDate: text("given_date"),
  submissionDate: text("submission_date"),
  checkedDate: text("checked_date"),
  completedQuestions: integer("completed_questions").default(0),
  totalQuestions: integer("total_questions").default(0),
  completed: boolean("completed").default(false),
});

export const insertYearSchema = createInsertSchema(years).omit({ id: true });
export const insertSemesterSchema = createInsertSchema(semesters).omit({ id: true });
export const insertSubjectSchema = createInsertSchema(subjects).omit({ id: true });
export const insertAssignmentSchema = createInsertSchema(assignments).omit({ id: true });

export type Year = typeof years.$inferSelect;
export type InsertYear = z.infer<typeof insertYearSchema>;
export type Semester = typeof semesters.$inferSelect;
export type InsertSemester = z.infer<typeof insertSemesterSchema>;
export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type Assignment = typeof assignments.$inferSelect;
export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
