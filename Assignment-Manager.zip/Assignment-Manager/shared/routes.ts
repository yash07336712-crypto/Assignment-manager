import { z } from 'zod';
import { insertYearSchema, insertSemesterSchema, insertSubjectSchema, insertAssignmentSchema, years, semesters, subjects, assignments } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  years: {
    list: {
      method: 'GET' as const,
      path: '/api/years',
      responses: {
        200: z.array(z.custom<typeof years.$inferSelect>()),
      },
    },
  },
  semesters: {
    list: {
      method: 'GET' as const,
      path: '/api/years/:yearId/semesters',
      responses: {
        200: z.array(z.custom<typeof semesters.$inferSelect>()),
      },
    },
  },
  subjects: {
    list: {
      method: 'GET' as const,
      path: '/api/semesters/:semesterId/subjects',
      responses: {
        200: z.array(z.custom<typeof subjects.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/subjects',
      input: insertSubjectSchema,
      responses: {
        201: z.custom<typeof subjects.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  assignments: {
    list: {
      method: 'GET' as const,
      path: '/api/subjects/:subjectId/assignments',
      responses: {
        200: z.array(z.custom<typeof assignments.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/assignments',
      input: insertAssignmentSchema,
      responses: {
        201: z.custom<typeof assignments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/assignments/:id',
      input: insertAssignmentSchema.partial(),
      responses: {
        200: z.custom<typeof assignments.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
        method: 'DELETE' as const,
        path: '/api/assignments/:id',
        responses: {
            204: z.void(),
            404: errorSchemas.notFound,
        },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
