import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useSemesters(yearId: number) {
  return useQuery({
    queryKey: [api.semesters.list.path, yearId],
    queryFn: async () => {
      const url = buildUrl(api.semesters.list.path, { yearId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch semesters");
      return api.semesters.list.responses[200].parse(await res.json());
    },
    enabled: !!yearId,
  });
}
