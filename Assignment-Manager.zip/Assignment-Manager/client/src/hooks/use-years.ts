import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useYears() {
  return useQuery({
    queryKey: [api.years.list.path],
    queryFn: async () => {
      const res = await fetch(api.years.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch years");
      return api.years.list.responses[200].parse(await res.json());
    },
  });
}
