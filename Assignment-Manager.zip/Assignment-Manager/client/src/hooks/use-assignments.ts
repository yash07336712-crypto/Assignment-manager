import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertAssignment } from "@shared/schema";

export function useAssignments(subjectId: number) {
  return useQuery({
    queryKey: [api.assignments.list.path, subjectId],
    queryFn: async () => {
      const url = buildUrl(api.assignments.list.path, { subjectId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch assignments");
      return api.assignments.list.responses[200].parse(await res.json());
    },
    enabled: !!subjectId,
  });
}

export function useCreateAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertAssignment) => {
      const validated = api.assignments.create.input.parse(data);
      const res = await fetch(api.assignments.create.path, {
        method: api.assignments.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create assignment");
      return api.assignments.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.assignments.list.path, data.subjectId] });
    },
  });
}

export function useUpdateAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertAssignment>) => {
      const validated = api.assignments.update.input.parse(updates);
      const url = buildUrl(api.assignments.update.path, { id });
      const res = await fetch(url, {
        method: api.assignments.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update assignment");
      return api.assignments.update.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.assignments.list.path, data.subjectId] });
    },
  });
}

export function useDeleteAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.assignments.delete.path, { id });
      const res = await fetch(url, {
        method: api.assignments.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete assignment");
    },
    onSuccess: () => {
      // Invalidate all assignment lists as a safe fallback since we don't have subjectId readily available in the delete context without passing it through
      queryClient.invalidateQueries({ queryKey: [api.assignments.list.path] });
    },
  });
}
