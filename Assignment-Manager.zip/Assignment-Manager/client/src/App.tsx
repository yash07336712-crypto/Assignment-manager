import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Year from "@/pages/Year";
import Semester from "@/pages/Semester";
import Subject from "@/pages/Subject";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/years/:id" component={Year} />
      <Route path="/semesters/:id" component={Semester} />
      <Route path="/subjects/:id" component={Subject} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
