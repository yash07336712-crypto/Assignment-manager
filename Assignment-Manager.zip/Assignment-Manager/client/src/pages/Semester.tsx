import { useRoute } from "wouter";
import { useSubjects } from "@/hooks/use-subjects";
import { useYears } from "@/hooks/use-years";
import { useSemesters } from "@/hooks/use-semesters";
import { Layout } from "@/components/Layout";
import { Link } from "wouter";
import { Loader2, BookOpen, ArrowRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SubjectDialog } from "@/components/SubjectDialog";

export default function Semester() {
  const [, params] = useRoute("/semesters/:id");
  const semesterId = parseInt(params?.id || "0");

  const { data: subjects, isLoading: subjectsLoading } = useSubjects(semesterId);
  
  // We need to fetch context (year -> semester hierarchy)
  // This is a bit inefficient without a dedicated 'getSemester' endpoint that returns relations
  // but works for this scale. Ideally API would return parent data.
  // For now, we'll fetch years and then semesters for the relevant year to reconstruct breadcrumbs.
  // BUT: We don't have the yearId from the URL here. 
  // Let's assume the user navigated hierarchically or fallback to a simpler display.
  // In a real app, I'd add a GET /api/semesters/:id endpoint that includes the year.
  
  // Hack for display: relying on the fact that we can get subjects.
  
  if (subjectsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <Layout 
      title="Subjects"
      subtitle="Select a subject to view and manage assignments."
      breadcrumbs={[
        { label: "Home", href: "/" },
        // Since we don't have easy access to parent year without more API calls,
        // we'll keep breadcrumbs simple or use history.back() conceptually
        { label: "Semester", href: `/semesters/${semesterId}` } 
      ]}
      action={
        <SubjectDialog 
          semesterId={semesterId} 
          trigger={
            <Button className="btn-primary gap-2">
              <Plus className="w-4 h-4" /> Add Subject
            </Button>
          }
        />
      }
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects?.map((subject) => (
          <Link key={subject.id} href={`/subjects/${subject.id}`}>
            <div className="group relative bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-1 transition-all duration-300 cursor-pointer h-full flex flex-col">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 rounded-lg bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-300">
                  <BookOpen className="w-6 h-6" />
                </div>
              </div>
              
              <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                {subject.name}
              </h3>
              
              <div className="mt-auto pt-6 flex items-center text-sm font-medium text-muted-foreground group-hover:text-primary transition-colors">
                View Assignments <ArrowRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
          </Link>
        ))}

        {(!subjects || subjects.length === 0) && (
          <div className="col-span-full py-20 flex flex-col items-center justify-center text-center border-2 border-dashed border-border rounded-2xl bg-muted/20">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <BookOpen className="w-8 h-8 text-muted-foreground opacity-50" />
            </div>
            <h3 className="text-lg font-bold text-foreground">No subjects yet</h3>
            <p className="text-muted-foreground max-w-sm mt-2 mb-6">
              Get started by adding subjects for this semester.
            </p>
            <SubjectDialog 
              semesterId={semesterId} 
              trigger={
                <Button variant="outline" className="gap-2">
                  <Plus className="w-4 h-4" /> Add First Subject
                </Button>
              }
            />
          </div>
        )}
      </div>
    </Layout>
  );
}
