import { useYears } from "@/hooks/use-years";
import { Layout } from "@/components/Layout";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { GraduationCap, ArrowRight, Loader2 } from "lucide-react";

export default function Home() {
  const { data: years, isLoading, error } = useYears();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-4">
        <div className="text-destructive font-bold text-lg">Error loading years</div>
        <div className="text-muted-foreground">Please try again later.</div>
      </div>
    );
  }

  return (
    <Layout 
      title="Academic Years" 
      subtitle="Select your current academic year to manage assignments and track your progress."
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {years?.map((year, index) => (
          <Link key={year.id} href={`/years/${year.id}`}>
            <div className="group relative bg-card hover:bg-white border border-border hover:border-primary/30 rounded-2xl p-8 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 cursor-pointer h-full overflow-hidden">
              <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 group-hover:scale-110 transition-all duration-500">
                <GraduationCap className="w-24 h-24 text-primary" />
              </div>
              
              <div className="relative z-10 flex flex-col h-full">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                  <span className="font-bold text-lg font-display">{index + 1}</span>
                </div>
                
                <h2 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {year.name}
                </h2>
                <p className="text-muted-foreground mb-8 line-clamp-2">
                  View semesters and subjects for your {year.name.toLowerCase()}.
                </p>
                
                <div className="mt-auto flex items-center text-sm font-semibold text-primary group-hover:translate-x-1 transition-transform">
                  View Semesters <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </div>
            </div>
          </Link>
        ))}

        {(!years || years.length === 0) && (
          <div className="col-span-full text-center py-12 bg-card/50 rounded-2xl border border-dashed border-border">
            <GraduationCap className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-foreground">No years found</h3>
            <p className="text-muted-foreground mt-1">Please contact your administrator to set up academic years.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
