import { useState } from "react";
import { useRoute } from "wouter";
import { useAssignments, useDeleteAssignment, useUpdateAssignment } from "@/hooks/use-assignments";
import { Layout } from "@/components/Layout";
import { Loader2, Plus, FileText, CheckCircle2, Calendar, Trash2, Edit2, MoreVertical, PieChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AssignmentDialog } from "@/components/AssignmentDialog";
import { cn } from "@/lib/utils";
import { format, parseISO } from "date-fns";

export default function Subject() {
  const [, params] = useRoute("/subjects/:id");
  const subjectId = parseInt(params?.id || "0");

  const { data: assignments, isLoading } = useAssignments(subjectId);
  const deleteMutation = useDeleteAssignment();
  const updateMutation = useUpdateAssignment();

  const [deleteId, setDeleteId] = useState<number | null>(null);

  const handleDelete = () => {
    if (deleteId) {
      deleteMutation.mutate(deleteId);
      setDeleteId(null);
    }
  };

  const toggleComplete = (assignment: any) => {
    updateMutation.mutate({
      id: assignment.id,
      completed: !assignment.completed
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  // Calculate progress
  const total = assignments?.length || 0;
  const completed = assignments?.filter(a => a.completed).length || 0;
  const progressPercentage = total === 0 ? 0 : Math.round((completed / total) * 100);

  return (
    <Layout 
      title="Assignments"
      subtitle="Track your tasks, deadlines, and grades."
      breadcrumbs={[
        { label: "Home", href: "/" },
        { label: "Subject", href: `/subjects/${subjectId}` } // Simplified breadcrumb
      ]}
      action={
        <AssignmentDialog 
          subjectId={subjectId} 
          trigger={
            <Button className="btn-primary gap-2 shadow-xl shadow-primary/20">
              <Plus className="w-4 h-4" /> New Assignment
            </Button>
          }
        />
      }
    >
      {/* Progress Overview */}
      <div className="mb-10 bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />
        
        <div className="flex items-center justify-between mb-4 relative z-10">
          <div>
            <h3 className="font-bold text-lg flex items-center gap-2">
              <PieChart className="w-5 h-5 text-blue-400" />
              Completion Status
            </h3>
            <p className="text-slate-400 text-sm">
              {completed} of {total} assignments completed
            </p>
          </div>
          <div className="text-3xl font-display font-bold text-blue-400">
            {progressPercentage}%
          </div>
        </div>
        <Progress value={progressPercentage} className="h-3 bg-slate-700/50" />
      </div>

      <div className="space-y-4">
        {assignments?.map((assignment) => {
           // Calculate questions progress
           const qProgress = assignment.totalQuestions > 0 
            ? Math.round((assignment.completedQuestions / assignment.totalQuestions) * 100) 
            : 0;

           return (
            <div 
              key={assignment.id} 
              className={cn(
                "group bg-card border rounded-xl p-5 transition-all duration-300 hover:shadow-md",
                assignment.completed ? "border-green-200 bg-green-50/30" : "border-border hover:border-primary/40"
              )}
            >
              <div className="flex flex-col md:flex-row md:items-center gap-4">
                {/* Status Icon */}
                <button 
                  onClick={() => toggleComplete(assignment)}
                  className={cn(
                    "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300",
                    assignment.completed 
                      ? "bg-green-100 text-green-600 hover:bg-green-200" 
                      : "bg-muted text-muted-foreground hover:bg-primary/10 hover:text-primary"
                  )}
                >
                  <CheckCircle2 className={cn("w-6 h-6", assignment.completed && "fill-current")} />
                </button>

                {/* Content */}
                <div className="flex-grow min-w-0">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider bg-muted/50 px-2 py-0.5 rounded">
                          #{assignment.number}
                        </span>
                        <h3 className={cn(
                          "text-lg font-bold truncate transition-colors",
                          assignment.completed ? "text-muted-foreground line-through decoration-2 decoration-green-200" : "text-foreground"
                        )}>
                          {assignment.title}
                        </h3>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground mt-2">
                        {assignment.givenDate && (
                          <div className="flex items-center gap-1.5" title="Given Date">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Given: {assignment.givenDate}</span>
                          </div>
                        )}
                        {assignment.submissionDate && (
                          <div className={cn("flex items-center gap-1.5 font-medium", !assignment.completed && "text-orange-600")} title="Due Date">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Due: {assignment.submissionDate}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions Menu */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <AssignmentDialog 
                          subjectId={subjectId} 
                          existingAssignment={assignment}
                          trigger={
                            <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50">
                              <Edit2 className="mr-2 h-4 w-4" /> Edit
                            </div>
                          }
                        />
                        <DropdownMenuItem 
                          className="text-destructive focus:text-destructive"
                          onClick={() => setDeleteId(assignment.id)}
                        >
                          <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Question Progress Bar */}
                  {assignment.totalQuestions > 0 && (
                    <div className="mt-4 flex items-center gap-3">
                      <div className="flex-grow h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className={cn("h-full transition-all duration-500 rounded-full", assignment.completed ? "bg-green-500" : "bg-primary")} 
                          style={{ width: `${qProgress}%` }}
                        />
                      </div>
                      <span className="text-xs font-medium text-muted-foreground whitespace-nowrap">
                        {assignment.completedQuestions} / {assignment.totalQuestions} Questions
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {(!assignments || assignments.length === 0) && (
          <div className="text-center py-20 bg-muted/20 rounded-2xl border-2 border-dashed border-border">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-bold text-foreground">No assignments yet</h3>
            <p className="text-muted-foreground mt-2 mb-6">
              Add your first assignment to start tracking.
            </p>
            <AssignmentDialog 
              subjectId={subjectId} 
              trigger={
                <Button variant="outline" className="gap-2">
                  <Plus className="w-4 h-4" /> Add Assignment
                </Button>
              }
            />
          </div>
        )}
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the assignment.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
