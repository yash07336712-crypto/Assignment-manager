import { useRoute } from "wouter";
import { useSemesters } from "@/hooks/use-semesters";
import { useYears } from "@/hooks/use-years";
import { Layout } from "@/components/Layout";
import { Link } from "wouter";
import { Loader2, CalendarRange, ArrowRight } from "lucide-react";

export default function Year() {
  const [, params] = useRoute("/years/:id");
  const yearId = parseInt(params?.id || "0");
  
  const { data: years } = useYears();
  const { data: semesters, isLoading, error } = useSemesters(yearId);
  
  const currentYear = years?.find(y => y.id === yearId);

  if (isLoading) {
    return (
      <Layout 
        title="Loading..." 
        breadcrumbs={[{ label: "Home", href: "/" }]}
      >
        <div className="flex justify-center py-20">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
      </Layout>
    );
  }

  if (error || !currentYear) {
    return (
      <Layout 
        title="Not Found" 
        breadcrumbs={[{ label: "Home", href: "/" }]}
      >
        <div className="text-center py-20">
          <h2 className="text-xl font-bold text-destructive">Year not found</h2>
          <Link href="/" className="text-primary hover:underline mt-4 inline-block">Return Home</Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout 
      title={currentYear.name}
      subtitle="Select a semester to view your enrolled subjects."
      breadcrumbs={[
        { label: "Years", href: "/" },
        { label: currentYear.name }
      ]}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {semesters?.map((semester, index) => (
          <Link key={semester.id} href={`/semesters/${semester.id}`}>
            <div className="group relative bg-white border border-border rounded-2xl p-8 hover:shadow-xl hover:shadow-primary/5 hover:border-primary/30 transition-all duration-300 cursor-pointer overflow-hidden">
              <div className="absolute top-0 left-0 w-2 h-full bg-primary/10 group-hover:bg-primary transition-colors duration-300" />
              
              <div className="pl-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                    <CalendarRange className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground border border-border px-2 py-1 rounded-md">
                    Semester {index + 1}
                  </span>
                </div>

                <h2 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {semester.name}
                </h2>
                <p className="text-muted-foreground mb-6">
                  Manage subjects and assignments for this semester period.
                </p>

                <div className="flex items-center text-sm font-semibold text-primary group-hover:translate-x-1 transition-transform">
                  View Subjects <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </div>
            </div>
          </Link>
        ))}

        {(!semesters || semesters.length === 0) && (
          <div className="col-span-full py-16 text-center border-2 border-dashed border-border rounded-2xl bg-muted/20">
            <CalendarRange className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-lg text-muted-foreground font-medium">No semesters listed for this year.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
