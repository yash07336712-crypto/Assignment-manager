import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { insertAssignmentSchema, type InsertAssignment, type Assignment } from "@shared/schema";
import { useCreateAssignment, useUpdateAssignment } from "@/hooks/use-assignments";
import { Loader2, Plus, Calendar, FileText, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";

// Extend schema for form handling (coerce numbers)
const formSchema = insertAssignmentSchema.extend({
  completedQuestions: z.coerce.number().min(0).default(0),
  totalQuestions: z.coerce.number().min(0).default(0),
});

type FormData = z.infer<typeof formSchema>;

interface AssignmentDialogProps {
  subjectId: number;
  existingAssignment?: Assignment;
  trigger?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function AssignmentDialog({ 
  subjectId, 
  existingAssignment, 
  trigger,
  open: controlledOpen,
  onOpenChange: setControlledOpen 
}: AssignmentDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;
  const setOpen = isControlled ? setControlledOpen : setInternalOpen;

  const createMutation = useCreateAssignment();
  const updateMutation = useUpdateAssignment();
  
  const isEditing = !!existingAssignment;
  const isPending = createMutation.isPending || updateMutation.isPending;

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: existingAssignment?.title ?? "",
      number: existingAssignment?.number ?? "",
      givenDate: existingAssignment?.givenDate ?? format(new Date(), "yyyy-MM-dd"),
      submissionDate: existingAssignment?.submissionDate ?? "",
      checkedDate: existingAssignment?.checkedDate ?? "",
      completedQuestions: existingAssignment?.completedQuestions ?? 0,
      totalQuestions: existingAssignment?.totalQuestions ?? 0,
      completed: existingAssignment?.completed ?? false,
      subjectId,
    },
  });

  // Reset form when dialog opens/closes or assignment changes
  useEffect(() => {
    if (open) {
      form.reset({
        title: existingAssignment?.title ?? "",
        number: existingAssignment?.number ?? "",
        givenDate: existingAssignment?.givenDate ?? format(new Date(), "yyyy-MM-dd"),
        submissionDate: existingAssignment?.submissionDate ?? "",
        checkedDate: existingAssignment?.checkedDate ?? "",
        completedQuestions: existingAssignment?.completedQuestions ?? 0,
        totalQuestions: existingAssignment?.totalQuestions ?? 0,
        completed: existingAssignment?.completed ?? false,
        subjectId,
      });
    }
  }, [open, existingAssignment, subjectId, form]);

  const onSubmit = (data: FormData) => {
    if (isEditing && existingAssignment) {
      updateMutation.mutate(
        { id: existingAssignment.id, ...data },
        {
          onSuccess: () => {
            setOpen(false);
          },
        }
      );
    } else {
      createMutation.mutate(data, {
        onSuccess: () => {
          setOpen(false);
          form.reset();
        },
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {trigger && <DialogTrigger asChild>{trigger}</DialogTrigger>}
      
      <DialogContent className="sm:max-w-[500px] bg-card border-border shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display font-bold text-foreground">
            {isEditing ? "Edit Assignment" : "New Assignment"}
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            {isEditing 
              ? "Make changes to your assignment details below." 
              : "Add a new assignment to track your progress."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label htmlFor="title" className="text-foreground font-medium">Assignment Title</Label>
              <Input 
                id="title" 
                placeholder="e.g. Linear Algebra Problem Set" 
                {...form.register("title")} 
                className="bg-background border-input focus-visible:ring-primary/20 transition-all"
              />
              {form.formState.errors.title && (
                <p className="text-xs text-destructive">{form.formState.errors.title.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="number" className="text-foreground font-medium">Assig. Number</Label>
              <Input 
                id="number" 
                placeholder="e.g. 1" 
                {...form.register("number")} 
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="givenDate" className="text-foreground font-medium">Given Date</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input 
                  id="givenDate" 
                  type="date"
                  {...form.register("givenDate")} 
                  className="pl-9 bg-background"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="submissionDate" className="text-foreground font-medium">Due Date</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input 
                  id="submissionDate" 
                  type="date"
                  {...form.register("submissionDate")} 
                  className="pl-9 bg-background"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="checkedDate" className="text-foreground font-medium">Checked Date</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input 
                  id="checkedDate" 
                  type="date"
                  {...form.register("checkedDate")} 
                  className="pl-9 bg-background"
                />
              </div>
            </div>

            <div className="col-span-2 grid grid-cols-2 gap-4 bg-muted/30 p-4 rounded-xl border border-border/50">
              <div className="space-y-2">
                <Label htmlFor="completedQuestions" className="text-foreground font-medium">Completed Qs</Label>
                <Input 
                  id="completedQuestions" 
                  type="number"
                  min="0"
                  {...form.register("completedQuestions")} 
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="totalQuestions" className="text-foreground font-medium">Total Qs</Label>
                <Input 
                  id="totalQuestions" 
                  type="number"
                  min="0"
                  {...form.register("totalQuestions")} 
                  className="bg-background"
                />
              </div>
            </div>

            <div className="col-span-2 flex items-center space-x-3 p-4 rounded-xl border border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer" onClick={() => form.setValue("completed", !form.getValues("completed"))}>
              <Checkbox 
                id="completed" 
                checked={form.watch("completed")}
                onCheckedChange={(checked) => form.setValue("completed", !!checked)}
                className="data-[state=checked]:bg-primary data-[state=checked]:border-primary w-5 h-5 border-2"
              />
              <div className="grid gap-1.5 leading-none cursor-pointer">
                <Label 
                  htmlFor="completed" 
                  className="text-sm font-semibold leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer text-primary"
                >
                  Mark as Completed
                </Label>
                <p className="text-xs text-muted-foreground">
                  Check this if you've finished all tasks
                </p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                isEditing ? "Save Changes" : "Create Assignment"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
