import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { ChevronRight, Home, BookOpen, GraduationCap } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
  breadcrumbs?: { label: string; href?: string }[];
  title: string;
  subtitle?: string;
  action?: ReactNode;
}

export function Layout({ children, breadcrumbs = [], title, subtitle, action }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-white to-blue-50/50 font-sans text-foreground">
      {/* Decorative background elements */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute top-[40%] -left-[10%] w-[40%] h-[40%] rounded-full bg-accent/5 blur-[100px]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {/* Breadcrumbs */}
        <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-8 animate-in fade-in slide-in-from-top-4 duration-500">
          <Link href="/" className="hover:text-primary transition-colors flex items-center gap-1">
            <Home className="w-4 h-4" />
            <span>Home</span>
          </Link>
          {breadcrumbs.map((crumb, i) => (
            <div key={i} className="flex items-center space-x-2">
              <ChevronRight className="w-3 h-3 text-muted-foreground/50" />
              {crumb.href ? (
                <Link href={crumb.href} className="hover:text-primary transition-colors font-medium">
                  {crumb.label}
                </Link>
              ) : (
                <span className="text-foreground font-medium">{crumb.label}</span>
              )}
            </div>
          ))}
        </nav>

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-100">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight leading-[1.1] mb-2 bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/80">
              {title}
            </h1>
            {subtitle && (
              <p className="text-lg text-muted-foreground max-w-2xl">{subtitle}</p>
            )}
          </div>
          {action && (
            <div className="shrink-0">
              {action}
            </div>
          )}
        </div>

        {/* Content */}
        <main className="animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
          {children}
        </main>

        <footer className="mt-20 pt-8 border-t border-border/40 text-center text-muted-foreground text-sm">
          <p>© {new Date().getFullYear()} Assignment Manager. Organize your academic journey.</p>
        </footer>
      </div>
    </div>
  );
}
