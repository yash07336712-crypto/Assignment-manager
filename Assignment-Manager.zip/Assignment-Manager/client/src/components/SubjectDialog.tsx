import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { insertSubjectSchema, type InsertSubject } from "@shared/schema";
import { useCreateSubject } from "@/hooks/use-subjects";
import { Loader2, BookOpen } from "lucide-react";

interface SubjectDialogProps {
  semesterId: number;
  trigger: React.ReactNode;
}

const formSchema = insertSubjectSchema;
type FormData = z.infer<typeof formSchema>;

export function SubjectDialog({ semesterId, trigger }: SubjectDialogProps) {
  const [open, setOpen] = useState(false);
  const createMutation = useCreateSubject();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      semesterId,
    },
  });

  const onSubmit = (data: FormData) => {
    createMutation.mutate(data, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 text-primary">
            <BookOpen className="w-6 h-6" />
          </div>
          <DialogTitle className="text-xl">Add New Subject</DialogTitle>
          <DialogDescription>
            Enter the name of the subject you want to add to this semester.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-2">
          <div className="space-y-2">
            <Label htmlFor="name">Subject Name</Label>
            <Input 
              id="name" 
              placeholder="e.g. Data Structures" 
              {...form.register("name")} 
              className="bg-background"
            />
            {form.formState.errors.name && (
              <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Add Subject
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
