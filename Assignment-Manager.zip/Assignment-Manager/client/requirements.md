## Packages
date-fns | For date formatting and handling
framer-motion | For smooth page transitions and micro-interactions

## Notes
API endpoints follow RESTful conventions defined in shared/routes.ts
Theme uses a clean, academic aesthetic with calm blues and crisp whites
