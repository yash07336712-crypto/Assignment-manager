import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed the database
  await storage.seed();

  app.get(api.years.list.path, async (req, res) => {
    const years = await storage.getYears();
    res.json(years);
  });

  app.get(api.semesters.list.path, async (req, res) => {
    const semesters = await storage.getSemesters(Number(req.params.yearId));
    res.json(semesters);
  });

  app.get(api.subjects.list.path, async (req, res) => {
    const subjects = await storage.getSubjects(Number(req.params.semesterId));
    res.json(subjects);
  });

  app.post(api.subjects.create.path, async (req, res) => {
    try {
      const input = api.subjects.create.input.parse(req.body);
      const subject = await storage.createSubject(input);
      res.status(201).json(subject);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
        return;
      }
      throw err;
    }
  });

  app.get(api.assignments.list.path, async (req, res) => {
    const assignments = await storage.getAssignments(Number(req.params.subjectId));
    res.json(assignments);
  });

  app.post(api.assignments.create.path, async (req, res) => {
    try {
      const input = api.assignments.create.input.parse(req.body);
      const assignment = await storage.createAssignment(input);
      res.status(201).json(assignment);
    } catch (err) {
        if (err instanceof z.ZodError) {
            res.status(400).json({ message: err.errors[0].message });
            return;
        }
        throw err;
    }
  });

  app.put(api.assignments.update.path, async (req, res) => {
    try {
        const input = api.assignments.update.input.parse(req.body);
        const updated = await storage.updateAssignment(Number(req.params.id), input);
        res.json(updated);
    } catch (err) {
        if (err instanceof z.ZodError) {
            res.status(400).json({ message: err.errors[0].message });
            return;
        }
        throw err;
    }
  });

  app.delete(api.assignments.delete.path, async (req, res) => {
      await storage.deleteAssignment(Number(req.params.id));
      res.status(204).send();
  });

  return httpServer;
}
