import {
  years, semesters, subjects, assignments,
  type Year, type InsertYear,
  type Semester, type InsertSemester,
  type Subject, type InsertSubject,
  type Assignment, type InsertAssignment
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getYears(): Promise<Year[]>;
  getSemesters(yearId: number): Promise<Semester[]>;
  getSubjects(semesterId: number): Promise<Subject[]>;
  getAssignments(subjectId: number): Promise<Assignment[]>;
  getAssignment(id: number): Promise<Assignment | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  updateAssignment(id: number, assignment: Partial<InsertAssignment>): Promise<Assignment>;
  deleteAssignment(id: number): Promise<void>;
  seed(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getYears(): Promise<Year[]> {
    return await db.select().from(years);
  }
  async getSemesters(yearId: number): Promise<Semester[]> {
    return await db.select().from(semesters).where(eq(semesters.yearId, yearId));
  }
  async getSubjects(semesterId: number): Promise<Subject[]> {
    return await db.select().from(subjects).where(eq(subjects.semesterId, semesterId));
  }
  async getAssignments(subjectId: number): Promise<Assignment[]> {
    return await db.select().from(assignments).where(eq(assignments.subjectId, subjectId));
  }
  async getAssignment(id: number): Promise<Assignment | undefined> {
    const [assignment] = await db.select().from(assignments).where(eq(assignments.id, id));
    return assignment;
  }
  async createSubject(subject: InsertSubject): Promise<Subject> {
    const [newSubject] = await db.insert(subjects).values(subject).returning();
    return newSubject;
  }
  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const [newAssignment] = await db.insert(assignments).values(assignment).returning();
    return newAssignment;
  }
  async updateAssignment(id: number, assignment: Partial<InsertAssignment>): Promise<Assignment> {
    const [updatedAssignment] = await db.update(assignments).set(assignment).where(eq(assignments.id, id)).returning();
    return updatedAssignment;
  }
  async deleteAssignment(id: number): Promise<void> {
    await db.delete(assignments).where(eq(assignments.id, id));
  }
  async seed(): Promise<void> {
    const existingYears = await this.getYears();
    if (existingYears.length === 0) {
      const [y1] = await db.insert(years).values({ name: "First Year" }).returning();
      const [y2] = await db.insert(years).values({ name: "Second Year" }).returning();
      const [y3] = await db.insert(years).values({ name: "Third Year" }).returning();

      await db.insert(semesters).values([
        { name: "Semester 1", yearId: y1.id },
        { name: "Semester 2", yearId: y1.id },
        { name: "Semester 1", yearId: y2.id },
        { name: "Semester 2", yearId: y2.id },
        { name: "Semester 1", yearId: y3.id },
        { name: "Semester 2", yearId: y3.id },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
